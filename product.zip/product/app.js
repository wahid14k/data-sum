const data = `Account ref:
M towhidul islam
Sukkari Dates 3 Kg   8,000 tk. Qty(2)
Delivery Charge :0 tk
Total:8,000 tk
Address: Bokshi sha bazer,Munshir hut, fulgazi,feni
Phone: 01622683823
Date:22/02/2025
Confirm by : Wahid-10376`;

function extractProductInfo(data) {
    const lines = data.split('\n');
    let productLine = '';
    
    for (let i = 2; i < lines.length; i++) { 
        if (lines[i].startsWith("Delivery Charge")) break; 
        productLine = lines[i].trim();
    }
    
    const productMatch = productLine.match(/^(.*?)\s+\d{1,3}(,\d{3})* tk/);
    const qtyMatch = productLine.match(/Qty\((\d+)\)/);
    
    const productName = productMatch ? productMatch[1] : 'Not found';
    const quantity = qtyMatch ? qtyMatch[1] : 'Not found';
    
    return { productName, quantity };
}

const result = extractProductInfo(data);
console.log(result);
