// const fs = require('fs');

// fs.readFile('data.txt', 'utf8', (err, data) => {
//     if (err) {
//         console.error('Error reading file:', err);
//         return;
//     }

//     function extractProductInfo(data) {
//         const entries = data.split(/\n\n+/); // Splitting multiple entries
//         let products = [];
        
//         entries.forEach(entry => {
//             const lines = entry.split('\n');
            
//             for (let i = 2; i < lines.length; i++) { 
//                 if (lines[i].startsWith("Delivery Charge"));
                
//                 const productMatch = lines[i].match(/^(.*?)\s+\d{1,3}(,\d{3})* tk/);
//                 const qtyMatch = lines[i].match(/Qty\((\d+)\)/);
                
//                 if (productMatch && qtyMatch) {
//                     products.push({
//                         productName: productMatch[1].trim(),
//                         quantity: parseInt(qtyMatch[1], 10)
//                     });
//                 }
//             }
//         });

//         return products;
//     }

//     const result = extractProductInfo(data);
//     console.log("Extracted Products:", result);
// });



const fs = require('fs');

fs.readFile('data.txt', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading file:', err);
        return;
    }

    function extractProductInfo(data) {
        const entries = data.split(/\n\n+/); // Splitting multiple entries
        let productMap = new Map();
        
        entries.forEach(entry => {
            const lines = entry.split('\n');
            
            for (let i = 2; i < lines.length; i++) { 
                if (lines[i].startsWith("Delivery Charge")) ;
                
                const productMatch = lines[i].match(/^(.*?)\s+\d{1,3}(,\d{3})* tk/);
                const qtyMatch = lines[i].match(/Qty\((\d+)\)/);
                
                if (productMatch && qtyMatch) {
                    let productName = productMatch[1].trim();
                    let quantity = parseInt(qtyMatch[1], 10);
                    
                    if (productMap.has(productName)) {
                        productMap.set(productName, productMap.get(productName) + quantity);
                    } else {
                        productMap.set(productName, quantity);
                    }
                }
            }
        });

        return Array.from(productMap, ([productName, quantity]) => ({ productName, quantity }));
    }

    const result = extractProductInfo(data);
    console.log("Extracted Products:", result);
});















